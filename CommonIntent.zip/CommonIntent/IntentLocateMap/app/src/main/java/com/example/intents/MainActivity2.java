package com.example.intents;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity2 extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activiry_main_2);
        Button locateMapName = (Button) findViewById(R.id.btnLocateMapName);
        locateMapName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText editLocationName = findViewById(R.id.editTextLocationName);
                String locationName = editLocationName.getText().toString();
                String newLocationName = "geo:0,0?q="+formatName(locationName);
                showMap(newLocationName);
            }
        });
        switchModeToLocateCoordinateButton();

    }

    public void showMap(String geoLocation) {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(geoLocation));
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        }
    }
    private void switchModeToLocateCoordinateButton(){
        Button switchModeButton2 = (Button) findViewById(R.id.btnSwitchMode2);
        switchModeButton2.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view)
            {
                startActivity(new Intent(MainActivity2.this, MainActivity.class));
            }
        });
    };

    public String formatName(String name)
    {
        char space = ' ';
        String comma = ",";
        name = name.replace(space, '+');
        name = name.replace(comma, "%2C");

        return name;
    };
}
