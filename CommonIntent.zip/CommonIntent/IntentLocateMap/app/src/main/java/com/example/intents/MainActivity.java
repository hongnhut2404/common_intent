package com.example.intents;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.content.Intent;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button locateMap = (Button) findViewById(R.id.btnLocateMap);
        locateMap.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view)
            {
                EditText editTextLat = findViewById(R.id.editTextLatitude);
                EditText editTextLong = findViewById(R.id.editTextLongitude);

                float latitude = Float.parseFloat(editTextLat.getText().toString());
                float longitude = Float.parseFloat(editTextLong.getText().toString());

                String Slocation = "geo:" +  latitude + "," + longitude +"?z=22&q=";
                showMap(Slocation);

            }
        });
        switchModeToLocateNameButton();
    }

    public void showMap(String geoLocation) {
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(geoLocation));
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        }
    }

    private void switchModeToLocateNameButton()
    {
        Button switchModeButton = (Button) findViewById(R.id.btnSwitchMode);
        switchModeButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view)
            {
                startActivity(new Intent(MainActivity.this, MainActivity2.class));
            }
        });
    }



}