package com.example.intentmusicvideo;

import android.app.DownloadManager;
import android.app.SearchManager;
import android.content.Intent;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class PlayMusicQueryActivity extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.play_music_query);

        Button playMusic = (Button) findViewById(R.id.btnPlayQueryMusic);
        playMusic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText textArtist = findViewById(R.id.editArtist);
                EditText textGenre = findViewById(R.id.editGenre);
                EditText textAlbum = findViewById(R.id.editAlbum);
                EditText textPlaylist = findViewById(R.id.editPlaylist);
                EditText textTitle = findViewById(R.id.editTitle);

                String infoArtist = textArtist.getText().toString();
                String infoGenre = textGenre.getText().toString();
                String infoAlbum = textAlbum.getText().toString();
                String infoPlaylist = textPlaylist.getText().toString();
                String infoTitle = textTitle.getText().toString();

                playAlbum(infoAlbum, infoArtist);
            }
        });


        Intent intent = this.getIntent();
        if (intent.getAction().compareTo(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH) == 0) {

            String mediaFocus = intent.getStringExtra(MediaStore.EXTRA_MEDIA_FOCUS);
            String query = intent.getStringExtra(SearchManager.QUERY);

            // Some of these extras might not be available depending on the search mode.
            String album = intent.getStringExtra(MediaStore.EXTRA_MEDIA_ALBUM);
            String artist = intent.getStringExtra(MediaStore.EXTRA_MEDIA_ARTIST);
            String genre = intent.getStringExtra("android.intent.extra.genre");
            String playlist = intent.getStringExtra("android.intent.extra.playlist");
            String title = intent.getStringExtra(MediaStore.EXTRA_MEDIA_TITLE);

            // Determine the search mode and use the corresponding extras.
            if (mediaFocus == null) {
                // 'Unstructured' search mode (backward compatible).
                playUnstructuredSearch(query);

            } else if (mediaFocus.compareTo("vnd.android.cursor.item/*") == 0) {
                if (query.isEmpty()) {
                    // 'Any' search mode.
                    playAnyPlaylist();
                } else {
                    // 'Unstructured' search mode.
                    playUnstructuredSearch(query);
                }

            } else if (mediaFocus.compareTo(MediaStore.Audio.Genres.ENTRY_CONTENT_TYPE) == 0) {
                // 'Genre' search mode.
                playGenre(genre);

            } else if (mediaFocus.compareTo(MediaStore.Audio.Artists.ENTRY_CONTENT_TYPE) == 0) {
                // 'Artist' search mode.
                playArtist(artist, genre);

            } else if (mediaFocus.compareTo(MediaStore.Audio.Albums.ENTRY_CONTENT_TYPE) == 0) {
                // 'Album' search mode.
                playAlbum(album, artist);

            } else if (mediaFocus.compareTo("vnd.android.cursor.item/audio") == 0) {
                // 'Song' search mode.
                playSong(album, artist, genre, title);

            } else if (mediaFocus.compareTo(MediaStore.Audio.Playlists.ENTRY_CONTENT_TYPE) == 0) {
                // 'Playlist' search mode.
                playPlaylist(album, artist, genre, playlist, title);
            }
        }

    }

    public void playPlaylist(String album, String artist, String genre, String playlist, String title) {
        Intent intent = new Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH);
        intent.putExtra(MediaStore.EXTRA_MEDIA_FOCUS,
                MediaStore.Audio.Albums.ENTRY_CONTENT_TYPE);
        intent.putExtra(MediaStore.EXTRA_MEDIA_ALBUM, album);

        intent.putExtra(MediaStore.EXTRA_MEDIA_FOCUS,
                MediaStore.Audio.Artists.ENTRY_CONTENT_TYPE);
        intent.putExtra(MediaStore.EXTRA_MEDIA_ARTIST, artist);

        intent.putExtra(MediaStore.EXTRA_MEDIA_FOCUS,
                MediaStore.Audio.Genres.ENTRY_CONTENT_TYPE);
        intent.putExtra(MediaStore.EXTRA_MEDIA_GENRE, genre);

        intent.putExtra(MediaStore.EXTRA_MEDIA_FOCUS,
                MediaStore.Audio.Genres.ENTRY_CONTENT_TYPE);
        intent.putExtra(MediaStore.EXTRA_MEDIA_ALBUM, album);

        intent.putExtra(MediaStore.EXTRA_MEDIA_FOCUS,
                MediaStore.EXTRA_MEDIA_PLAYLIST);
        intent.putExtra(MediaStore.EXTRA_MEDIA_PLAYLIST, playlist);

        intent.putExtra(MediaStore.EXTRA_MEDIA_FOCUS,
                MediaStore.EXTRA_MEDIA_TITLE);
        intent.putExtra(MediaStore.EXTRA_MEDIA_TITLE, title);

        intent.putExtra(SearchManager.QUERY, playlist);
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        }
    }

    public void playSong(String album, String artist, String genre, String title) {
        Intent intent = new Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH);
        intent.putExtra(MediaStore.EXTRA_MEDIA_FOCUS,
                MediaStore.Audio.Artists.ENTRY_CONTENT_TYPE);
        intent.putExtra(MediaStore.EXTRA_MEDIA_ARTIST, artist);

        intent.putExtra(MediaStore.EXTRA_MEDIA_FOCUS,
                MediaStore.Audio.Albums.ENTRY_CONTENT_TYPE);
        intent.putExtra(MediaStore.EXTRA_MEDIA_ALBUM, album);

        intent.putExtra(MediaStore.EXTRA_MEDIA_FOCUS,
                MediaStore.Audio.Genres.ENTRY_CONTENT_TYPE);
        intent.putExtra(MediaStore.EXTRA_MEDIA_GENRE, genre);

        intent.putExtra(MediaStore.EXTRA_MEDIA_FOCUS,
                MediaStore.EXTRA_MEDIA_TITLE);
        intent.putExtra(MediaStore.EXTRA_MEDIA_TITLE, title);
        intent.putExtra(SearchManager.QUERY, title);

        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        }
    }


    public void playAlbum(String album, String artist) {
        Intent intent = new Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH);
        intent.putExtra(MediaStore.EXTRA_MEDIA_FOCUS,
                MediaStore.Audio.Artists.ENTRY_CONTENT_TYPE);
        intent.putExtra(MediaStore.EXTRA_MEDIA_ARTIST, artist);

        intent.putExtra(MediaStore.EXTRA_MEDIA_FOCUS,
                MediaStore.Audio.Albums.ENTRY_CONTENT_TYPE);
        intent.putExtra(MediaStore.EXTRA_MEDIA_ALBUM, album);
        intent.putExtra(SearchManager.QUERY, album);

        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        }
    }

    public void playGenre(String genre) {
        Intent intent = new Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH);
        intent.putExtra(MediaStore.EXTRA_MEDIA_FOCUS,
                MediaStore.Audio.Genres.ENTRY_CONTENT_TYPE);
        intent.putExtra(MediaStore.EXTRA_MEDIA_GENRE, genre);
        intent.putExtra(SearchManager.QUERY, genre);
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        }
    }
    public void playArtist(String artist, String genre) {
        Intent intent = new Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH);
        intent.putExtra(MediaStore.EXTRA_MEDIA_FOCUS,
                MediaStore.Audio.Genres.ENTRY_CONTENT_TYPE);
        intent.putExtra(MediaStore.EXTRA_MEDIA_GENRE, genre);

        intent.putExtra(MediaStore.EXTRA_MEDIA_FOCUS,
                MediaStore.Audio.Artists.ENTRY_CONTENT_TYPE);
        intent.putExtra(MediaStore.EXTRA_MEDIA_ARTIST, artist);
        intent.putExtra(SearchManager.QUERY, artist);

        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        }
    }


    public void playAnyPlaylist() {
        Intent intent = new Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH);
        intent.putExtra(MediaStore.EXTRA_MEDIA_FOCUS,
                "vnd.android.cursor.item/*");

        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        }
    }

    public void playUnstructuredSearch(String query) {
        Intent intent = new Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH);
        intent.putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*");
        intent.putExtra(SearchManager.QUERY, query);

        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        }
    }
}